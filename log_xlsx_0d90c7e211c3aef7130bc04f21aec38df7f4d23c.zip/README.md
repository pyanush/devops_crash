Status of Last Deployment:<br>
<img src="https://github.com/pyanush/devops_crash/workflows/Pavlo_polyak_25021982/badge.svg?branch=pavlo_polyak_25021982"><br>


# Resume

### Pavlo Polyak
Web-designer

```
I believe that having such important qualities as 
responsibility, purposefulness, diligence and perseverance 
will help me to prove myself successfully in work. 
The main thing is to have the opportunity 
for development and career growth
```


### Languages
- 🇺🇦 УКРАЇНСЬКА
- 🇷🇺 РУССКИЙ
- 🇺🇸 ENGLISH

### Skills
- [HTML-CSS-JS](https://raw.githack.com/PolyakPavlo/MERN/main/barmaglot/index.html)
- [HTML-JQuery-Git-Json](https://raw.githack.com/PolyakPavlo/MERN/main/barmaglot/trans.html)
   
- Python
  - [Webdriver](https://github.com/PolyakPavlo/DevOps/blob/dev/py/olx_spider.py)
  - [Selenium](https://github.com/PolyakPavlo/DevOps/blob/dev/py/selenium.py)
  - [API](https://github.com/PolyakPavlo/DevOps/blob/dev/py/API.py)
  - [Ddos](https://github.com/PolyakPavlo/DevOps/blob/dev/py/run.py)
  - [Web spider](https://github.com/PolyakPavlo/DevOps/blob/dev/py/thread.py)
  
- NODE.js (Mongodb,Express,React,Node)

- JAVA

- Adobe
  - InDesign
  - Photoshop
  - Illustrator

- GIT
- LINUX
- WINDOWS
  - MICROSOFT OFFICE

### Character

```
Brave, positive, savvy guy. 
Full of energy and strength to accomplish 
great things there is a sense of justice, 
virtue, rigor. Faithful and honest friend
```

### Likes😃
- Music
- Mountain
- Book
- Cooking

### Dislikes😞
- Lazy

### Wants🥺
- TO BE CLEVER AND HEALTHY 
- TO READ MORE

### Education
    Every free times

### Experience
- 2002-2008 newpaper "MB"
- 2008-2018 newpaper "Pogliad"
- 2018-until newpaper "MB"

### Contacts
- 099 091 36 77
- https://t.me/PashaPolyak
- poliakpavlo@gmail.com
